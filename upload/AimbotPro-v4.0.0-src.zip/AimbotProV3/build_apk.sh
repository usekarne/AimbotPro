#!/usr/bin/env bash
# AimbotPro v3.0 — APK build script
# Usage:  bash build_apk.sh [debug|release]
set -euo pipefail

cd "$(dirname "$0")"

BUILD_TYPE="${1:-debug}"

# Try Android SDK from env first, then local.properties, then common locations.
if [[ -z "${ANDROID_HOME:-}${ANDROID_SDK_ROOT:-}" ]]; then
    if [[ -f local.properties ]]; then
        SDK_DIR=$(grep -E "^sdk\.dir=" local.properties | cut -d= -f2)
        export ANDROID_HOME="$SDK_DIR"
        export ANDROID_SDK_ROOT="$SDK_DIR"
    else
        for p in "/home/z/android-sdk" "/opt/android-sdk" "$HOME/Android/Sdk"; do
            if [[ -d "$p" ]]; then
                export ANDROID_HOME="$p"
                export ANDROID_SDK_ROOT="$p"
                break
            fi
        done
    fi
fi

if [[ -z "${ANDROID_HOME:-}" ]]; then
    echo "[!] Android SDK not found. Set ANDROID_HOME or create local.properties with:"
    echo "    sdk.dir=/path/to/Android/Sdk"
    exit 1
fi
echo "[i] Using SDK at: $ANDROID_HOME"

GRADLE_BIN="./gradlew"
if ! [[ -x "$GRADLE_BIN" ]]; then
    if command -v gradle >/dev/null 2>&1; then
        GRADLE_BIN="gradle"
    else
        echo "[!] No gradle wrapper and no system gradle. Run:"
        echo "    gradle wrapper --gradle-version 8.5 --distribution-type bin"
        exit 1
    fi
fi

case "$BUILD_TYPE" in
    debug|release) ;;
    *)
        echo "[!] Build type must be 'debug' or 'release' (got: $BUILD_TYPE)"
        exit 1
        ;;
esac

TASK="assemble${BUILD_TYPE^}"
echo "[*] Building AimbotPro v3.0 ($BUILD_TYPE)..."
"$GRADLE_BIN" "$TASK" --console=plain

APK="app/build/outputs/apk/$BUILD_TYPE/app-$BUILD_TYPE.apk"
if [[ -f "$APK" ]]; then
    echo "[OK] APK built: $APK"
    cp -v "$APK" "AimbotPro-v3.0.0-$BUILD_TYPE.apk" || true
else
    echo "[!] Build completed but APK not found at: $APK"
    exit 2
fi
